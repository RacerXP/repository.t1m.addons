plugin.video.hgtv.canada
================

Kodi Addon for HGTV Canada website

Version 1.0.2 Cleanup subtitles and improve vid res
Version 1.0.1 Initial release


