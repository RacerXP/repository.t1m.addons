plugin.video.syfy
================

Kodi Addon for Syfy

Version 1.0.7 Added show caching - should load faster
Version 1.0.6 Added user view select, sort
Version 1.0.5 website change
Version 1.0.4 cleanup
Version 1.0.3 Set proper content view, added metadata, added subtitles
Version 1.0.2 Add descriptions
Version 1.0.1 initial release

