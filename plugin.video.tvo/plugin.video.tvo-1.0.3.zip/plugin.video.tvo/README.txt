plugin.video.tvo
================

XBMC Addon for TVO.org Video website

Version 1.0.3 Added retry and increased timeout for http requests
Version 1.0.2 Subtitle support added
Version 1.0.1 initial release

