plugin.video.sprout
================

XBMC Addon for Sprout for Kids website

Version 1.0.9 Added user select views
Version 1.0.8 Added subtitles, meta-data
Version 1.0.7 Website change
Version 1.0.5 Website change
Version 1.0.4 Website change
version 1.0.2 initial release

