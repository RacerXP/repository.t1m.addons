plugin.video.sprout
================

Kodi Addon for Sprout for Kids website

Version 1.0.11 Website change
Version 1.0.10 Added Show caching - should load faster
Version 1.0.9 Added user select views
Version 1.0.8 Added subtitles, meta-data
Version 1.0.7 Website change
Version 1.0.5 Website change
Version 1.0.4 Website change
version 1.0.2 initial release

