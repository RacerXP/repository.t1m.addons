plugin.video.esquire
================

Kodi Addon for Esquire TV website

Version 1.0.4 Website Change
Version 1.0.3 Added user select views
Version 1.0.2 Added Subtitles, Metadata and views
Version 1.0.1 initial release

