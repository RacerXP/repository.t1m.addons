plugin.video.smithsonian
================

XBMC Addon for Smithsonian Channel website

Version 1.0.8 Added show caching - should load faster
Version 1.0.7 Added select content type
Version 1.0.6 Added metadata and views
Version 1.0.4 Fix for 1080 and audio only choices (website change)
version 1.0.3 Added subtitle and proxy support
version 1.0.1 initial release

