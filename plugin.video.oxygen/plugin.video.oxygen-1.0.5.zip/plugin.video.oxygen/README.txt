plugin.video.oxygen
================

Kodi Addon for Oxygen Channel website

Version 1.0.5 website changes
Version 1.0.4 Website change
Version 1.0.3 Added user select views
Version 1.0.2 Added subtitles, metadata, fixed views
Version 1.0.1 initial release

