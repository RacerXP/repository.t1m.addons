plugin.video.thinktv
================

Kodi Addon for Think TV PBS Video website

Version 1.0.20 add 1080 support
Version 1.0.19 fix for m3u8 url change
Version 1.0.18 add'l fix for PBSKids .flv because I'm an idiot
Version 1.0.17 changed PBSKids to use progressive mp4 rather than rtmp (thanks to toejam)
Version 1.0.15 Added icons (thanks to freem@n), featured programs, popular programs
Version 1.0.14 Cleanup and minor bug fixes
Version 1.0.13 Added PBS Kids videos
Version 1.0.12 Added SD/HD video choice
Version 1.0.11 Website changes
Version 1.0.10 Improved subtitle handling
Version 1.0.9 Improved subtitle handling
Version 1.0.8 Subtitle support added
Version 1.0.7 Added Proxy support
Version 1.0.6 Fix for unicode errors
Version 1.0.5 Add Clips and Previews, speed improvements for big filelist
Version 1.0.4 Fix for videos with no duration
Version 1.0.3 Language strings cleanup
Version 1.0.2 Added Search and A-Z Program listings
Version 1.0.1 initial release

