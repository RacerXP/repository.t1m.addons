plugin.video.npr
================

Kodi Addon for NPR Music website

version 1.0.1 initial release
version 1.0.2 clean-up of genre
Version 1.0.3 - website changes
Version 1.0.4 - website changes
Version 1.0.5 website changes, added views


