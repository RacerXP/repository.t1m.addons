plugin.video.metv
================

XBMC Addon for MeTV website

Version 1.4.1 Website change
Version 1.4.0 added metadata, subtitles and views
Version 1.1.2 fix for commercials
Version 1.1.1 Improved bitrate speeds for videos
version 1.0.1 initial release

