plugin.video.foodnetwork.canada
================

Kodi Addon for Food Network Canada website
Version 1.0.1 Initial version
Version 1.0.2 fix for non playing

