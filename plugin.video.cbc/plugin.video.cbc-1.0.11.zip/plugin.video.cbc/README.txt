plugin.video.cbc
================

Kodi Addon for CBC Video website

Version 1.0.11 Added 'episodes' view
Version 1.0.10 Improve video resolution
Version 1.0.9 Improve video resolution
Version 1.0.8 Improve video resolution
Version 1.0.7 Added Sports and Digital Archives
Version 1.0.6 Fix for Live Streams
Version 1.0.5 Added News Category
Version 1.0.4 Add Next page function
Version 1.0.3 Fix More Shows bug
Version 1.0.2 Add disable subtitles function
Version 1.0.1 initial release

