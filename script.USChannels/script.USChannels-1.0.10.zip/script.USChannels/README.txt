script.USChannels ---- Kodi script for playing and epg of US channels

Version 1.0.10 set 1080, fixed minutes calc
Version 1.0.7 Init release
