script.USChannels ---- script for playing and epg of US channels

Version 1.0.7 Init release
