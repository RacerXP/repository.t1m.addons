plugin.video.mcorp
================

Kodi Addon for Mediacorp (toggle.sg)

Version 1.5.4 added metadata caching
Version 1.5.3 fix bug in page start
Version 1.5.2 metadata optimization, setting to disable
Version 1.5.0 Added metadata, optimized for ftv skin
Version 1.4.3 Added all channels tv-catchup
Version 1.4.2 Fix for Telemovies
Version 1.4.1 initial toggle.sg release

