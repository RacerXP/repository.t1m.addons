plugin.video.fyi
================

Kodi Addon for FYI TV Video website

Version 1.0.1 initial release

