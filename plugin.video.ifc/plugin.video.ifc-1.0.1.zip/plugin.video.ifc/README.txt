plugin.video.ifc
================

Kodi Video Addon for IFC

Version 1.0.1 initial release

